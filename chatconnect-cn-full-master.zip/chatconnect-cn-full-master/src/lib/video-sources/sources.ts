import type { Room } from "livekit-client";
import type {
  PreparedVideoSource,
  VideoFileOptions,
  VideoSource,
} from "./types.ts";

const cameraConstraints: MediaTrackConstraints = {
  width: { ideal: 1280 },
  height: { ideal: 720 },
  frameRate: { ideal: 24, max: 30 },
  facingMode: "user",
};

export class CameraSource implements VideoSource {
  readonly kind = "camera" as const;
  isSupported() {
    return Boolean(navigator.mediaDevices?.getUserMedia);
  }
  async prepare(_room: Room): Promise<PreparedVideoSource> {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: cameraConstraints,
      audio: false,
    });
    const track = stream.getVideoTracks()[0];
    if (!track) throw new Error("无法获取摄像头画面。");
    return { kind: this.kind, track, dispose: () => track.stop() };
  }
}

export class ScreenShareSource implements VideoSource {
  readonly kind = "screen-share" as const;
  isSupported() {
    return Boolean(navigator.mediaDevices?.getDisplayMedia);
  }
  async prepare(_room: Room): Promise<PreparedVideoSource> {
    if (!navigator.mediaDevices?.getDisplayMedia)
      throw new Error("此设备不支持屏幕共享。");
    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: true,
      audio: false,
    });
    const track = stream.getVideoTracks()[0];
    if (!track) throw new Error("无法获取要共享的屏幕。");
    return { kind: this.kind, track, dispose: () => track.stop() };
  }
}

export class VideoFileSource implements VideoSource {
  readonly kind = "video-file" as const;
  constructor(private readonly options: VideoFileOptions) {}
  isSupported() {
    return (
      typeof document !== "undefined" &&
      "captureStream" in HTMLCanvasElement.prototype
    );
  }
  async prepare(_room: Room): Promise<PreparedVideoSource> {
    if (!this.options.file && !this.options.url)
      throw new Error("请选择 MP4 文件。");
    if (!this.isSupported()) throw new Error("此浏览器不支持发送视频文件。");

    const objectUrl = this.options.file
      ? URL.createObjectURL(this.options.file)
      : null;
    const video = document.createElement("video");
    video.src = objectUrl ?? this.options.url!;
    video.muted = true;
    video.playsInline = true;
    // A selected video remains the active camera source for the whole call.
    // It must only stop when the user replaces it or switches back to camera.
    video.loop = true;
    video.preload = "auto";
    if (!objectUrl) video.crossOrigin = "anonymous";
    await new Promise<void>((resolve, reject) => {
      const ready = () => {
        cleanup();
        resolve();
      };
      const failed = () => {
        cleanup();
        reject(new Error("无法读取 MP4 文件。"));
      };
      const cleanup = () => {
        video.removeEventListener("canplay", ready);
        video.removeEventListener("error", failed);
      };
      video.addEventListener("canplay", ready, { once: true });
      video.addEventListener("error", failed, { once: true });
      video.load();
    });
    if (
      this.options.startedAt &&
      video.duration > 0 &&
      Number.isFinite(video.duration)
    ) {
      const elapsed = Math.max(0, (Date.now() - this.options.startedAt) / 1000);
      video.currentTime = elapsed % video.duration;
    }

    const canvas = document.createElement("canvas");
    canvas.width = Math.max(2, video.videoWidth || 1280);
    canvas.height = Math.max(2, video.videoHeight || 720);
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) throw new Error("无法开始渲染视频。");
    let frameRequest = 0;
    let disposed = false;
    const render = () => {
      if (disposed) return;
      if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA)
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
      frameRequest = window.requestAnimationFrame(render);
    };
    render();
    await video.play();
    const stream = canvas.captureStream(24);
    const track = stream.getVideoTracks()[0];
    if (!track) throw new Error("无法创建视频发送轨道。");
    const keepPlaying = () => {
      if (disposed) return;
      video.currentTime = 0;
      void video.play();
    };
    video.addEventListener("ended", keepPlaying);
    const dispose = () => {
      disposed = true;
      window.cancelAnimationFrame(frameRequest);
      video.pause();
      video.removeEventListener("ended", keepPlaying);
      video.removeAttribute("src");
      video.load();
      track.stop();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
    return {
      kind: this.kind,
      track,
      dispose,
      pause: async () => {
        video.pause();
      },
      resume: async () => {
        await video.play();
      },
    };
  }
}

/** Adapter boundary for a future worker-published processed track. */
export class AISource implements VideoSource {
  readonly kind = "ai" as const;
  isSupported() {
    return false;
  }
  async prepare(_room: Room): Promise<PreparedVideoSource> {
    throw new Error("人工智能视频来源目前尚未开放。");
  }
}
